﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.cmbPort = New System.Windows.Forms.ComboBox()
        Me.btnconectar = New System.Windows.Forms.Button()
        Me.btndesconectar = New System.Windows.Forms.Button()
        Me.txtrecibe = New System.Windows.Forms.TextBox()
        Me.txtenvia = New System.Windows.Forms.TextBox()
        Me.btnenviar = New System.Windows.Forms.Button()
        Me.lblestado = New System.Windows.Forms.Label()
        Me.sppuerto = New System.IO.Ports.SerialPort(Me.components)
        Me.Btguardar = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'cmbPort
        '
        Me.cmbPort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbPort.FormattingEnabled = True
        Me.cmbPort.Location = New System.Drawing.Point(26, 21)
        Me.cmbPort.Name = "cmbPort"
        Me.cmbPort.Size = New System.Drawing.Size(121, 21)
        Me.cmbPort.TabIndex = 0
        '
        'btnconectar
        '
        Me.btnconectar.Location = New System.Drawing.Point(178, 21)
        Me.btnconectar.Name = "btnconectar"
        Me.btnconectar.Size = New System.Drawing.Size(75, 23)
        Me.btnconectar.TabIndex = 1
        Me.btnconectar.Text = "Conectar"
        Me.btnconectar.UseVisualStyleBackColor = True
        '
        'btndesconectar
        '
        Me.btndesconectar.Location = New System.Drawing.Point(271, 21)
        Me.btndesconectar.Name = "btndesconectar"
        Me.btndesconectar.Size = New System.Drawing.Size(83, 23)
        Me.btndesconectar.TabIndex = 2
        Me.btndesconectar.Text = "Desconectar"
        Me.btndesconectar.UseVisualStyleBackColor = True
        '
        'txtrecibe
        '
        Me.txtrecibe.Location = New System.Drawing.Point(26, 63)
        Me.txtrecibe.Multiline = True
        Me.txtrecibe.Name = "txtrecibe"
        Me.txtrecibe.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtrecibe.Size = New System.Drawing.Size(519, 186)
        Me.txtrecibe.TabIndex = 3
        '
        'txtenvia
        '
        Me.txtenvia.Location = New System.Drawing.Point(26, 287)
        Me.txtenvia.Multiline = True
        Me.txtenvia.Name = "txtenvia"
        Me.txtenvia.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtenvia.Size = New System.Drawing.Size(193, 33)
        Me.txtenvia.TabIndex = 4
        '
        'btnenviar
        '
        Me.btnenviar.Location = New System.Drawing.Point(267, 287)
        Me.btnenviar.Name = "btnenviar"
        Me.btnenviar.Size = New System.Drawing.Size(87, 33)
        Me.btnenviar.TabIndex = 5
        Me.btnenviar.Text = "Enviar"
        Me.btnenviar.UseVisualStyleBackColor = True
        '
        'lblestado
        '
        Me.lblestado.AutoSize = True
        Me.lblestado.Location = New System.Drawing.Point(23, 252)
        Me.lblestado.Name = "lblestado"
        Me.lblestado.Size = New System.Drawing.Size(0, 13)
        Me.lblestado.TabIndex = 6
        '
        'sppuerto
        '
        '
        'Btguardar
        '
        Me.Btguardar.Location = New System.Drawing.Point(377, 287)
        Me.Btguardar.Name = "Btguardar"
        Me.Btguardar.Size = New System.Drawing.Size(87, 33)
        Me.Btguardar.TabIndex = 7
        Me.Btguardar.Text = "Guardar"
        Me.Btguardar.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(557, 345)
        Me.Controls.Add(Me.Btguardar)
        Me.Controls.Add(Me.lblestado)
        Me.Controls.Add(Me.btnenviar)
        Me.Controls.Add(Me.txtenvia)
        Me.Controls.Add(Me.txtrecibe)
        Me.Controls.Add(Me.btndesconectar)
        Me.Controls.Add(Me.btnconectar)
        Me.Controls.Add(Me.cmbPort)
        Me.Name = "Form1"
        Me.Text = "Fibra Optica"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents cmbPort As ComboBox
    Friend WithEvents btnconectar As Button
    Friend WithEvents btndesconectar As Button
    Friend WithEvents txtrecibe As TextBox
    Friend WithEvents txtenvia As TextBox
    Friend WithEvents btnenviar As Button
    Friend WithEvents lblestado As Label
    Friend WithEvents sppuerto As IO.Ports.SerialPort
    Friend WithEvents Btguardar As Button
End Class
