# LCD_I2C_Component
Componente para la LCD mediante módulo I2C PCF8574AT PSoC5LP
