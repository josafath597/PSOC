/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
    Proyecto Terminal 
    Sistema de Medición y control de fuerza de tensado para Fibra Óptica de Vidrio
    Fabian Josafat Cardenas Aldana
*/

#include "project.h"
#include <stdlib.h>
#include <stdio.h>
/**************I2C*********/
int fila;
int columna;
/**********UART*************/
#define STRBUF_LEN 16
int recibir=0;
int str_index=0;
char str4[STRBUF_LEN+1]={0};
float NW;
int N;
/***Variables para ADC**/
int32 entero[2],voltaje[2];
float32 volt[2];
float aux[2];
char str[16];
char str2[16];
char str3[16];
char str5[STRBUF_LEN+1];
/**Variables para el Teclado*/
unsigned int rango;
unsigned int tx=0;
unsigned int limite=4;

int bit0_MSB,bit1,bit2,bit3_LSB,cuenta=0,numeroint=0;
char i='\0';
char numero[5];

char8 Keypad_1_Key[4][4]={
    {'1','4','7','*'},
    {'2','5','8','0'},
    {'3','6','9','#'},
    {'A','B','C' ,'D'}
};
/**Valores del Teclado**/
void LeerTecla(){
    bit0_MSB=Bit0_MSB_Read();
    bit1=Bit1_Read();
    bit2=Bit2_Read();
    bit3_LSB=Bit3_LSB_Read();
    if((bit0_MSB==0)&&(bit1==0)&&(bit2==0)&&(bit3_LSB==0))//1
        i=Keypad_1_Key[0][0];
    if((bit0_MSB==0)&&(bit1==0)&&(bit2==0)&&(bit3_LSB==1))//2
        i=Keypad_1_Key[1][0];
    if((bit0_MSB==0)&&(bit1==0)&&(bit2==1)&&(bit3_LSB==0))//3
        i=Keypad_1_Key[2][0];
    if((bit0_MSB==0)&&(bit1==0)&&(bit2==1)&&(bit3_LSB==1))//A
        i=Keypad_1_Key[3][0];
    if((bit0_MSB==0)&&(bit1==1)&&(bit2==0)&&(bit3_LSB==0))//4
        i=Keypad_1_Key[0][1];
    if((bit0_MSB==0)&&(bit1==1)&&(bit2==0)&&(bit3_LSB==1))//5
        i=Keypad_1_Key[1][1];
    if((bit0_MSB==0)&&(bit1==1)&&(bit2==1)&&(bit3_LSB==0))//6
        i=Keypad_1_Key[2][1];
    if((bit0_MSB==0)&&(bit1==1)&&(bit2==1)&&(bit3_LSB==1))//B
        i=Keypad_1_Key[3][1];
    if((bit0_MSB==1)&&(bit1==0)&&(bit2==0)&&(bit3_LSB==0))//7
        i=Keypad_1_Key[0][2];
    if((bit0_MSB==1)&&(bit1==0)&&(bit2==0)&&(bit3_LSB==1))//8
        i=Keypad_1_Key[1][2];
    if((bit0_MSB==1)&&(bit1==0)&&(bit2==1)&&(bit3_LSB==0))//9
        i=Keypad_1_Key[2][2];
    if((bit0_MSB==1)&&(bit1==0)&&(bit2==1)&&(bit3_LSB==1))//C
        i=Keypad_1_Key[3][2];
    if((bit0_MSB==1)&&(bit1==1)&&(bit2==0)&&(bit3_LSB==0))//*
        i=Keypad_1_Key[0][3];
    if((bit0_MSB==1)&&(bit1==1)&&(bit2==0)&&(bit3_LSB==1))//0
        i=Keypad_1_Key[1][3];
    if((bit0_MSB==1)&&(bit1==1)&&(bit2==1)&&(bit3_LSB==0))//#
        i=Keypad_1_Key[2][3];
    if((bit0_MSB==1)&&(bit1==1)&&(bit2==1)&&(bit3_LSB==1))//D
        i=Keypad_1_Key[3][3];
}
/**Rutina para Leer el teclado**/
CY_ISR(LeerTeclaInt){
    LeerTecla();
    if((i!='A')&&(i!='B')&&(i!='C')&&(i!='D')&&(i!='*')&&(i!='#'))
    {
        if(cuenta<=3)
        {
            numero[cuenta]=i;
            cuenta++;
        }
    }
    if(i=='C')
    {
        numero[0]='\0';
        numero[1]='\0';
        numero[2]='\0';
        numero[3]='\0';
        cuenta=0;
    }
    if(i=='*')
    {
        DIR_Write(0);
        STEP_Write(1);
        CyDelay(10);
        STEP_Write(0);
        CyDelay(100);
    }
    if(i=='#')
    {
        DIR_Write(1);
        STEP_Write(1);
        CyDelay(10);
        STEP_Write(0);
        CyDelay(100);
    }
}
/**Rutina para enviar datos*/
CY_ISR(Enviar)
{
    sprintf(str3,"%d %d ",voltaje[0],voltaje[1]);
    UART_PutString(str3);
    UART_PutString(str4);
    UART_PutString(" \n");
}
/************************************************************************************/
int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    /*********Inicializar Variables*****/
    I2C_Start();
    LCD_I2C_start();
    Opamp_Start();
    Opamp2_Start();
    pulisr_StartEx(LeerTeclaInt);
    isrEnvio_StartEx(Enviar);
    UART_Start();
    ADC_Start();
    AMux_1_Start();
    /************Inicio de Programa****/
    columna=0;
    fila=0;
    LCD_I2C_setCursor(columna,fila);
    LCD_I2C_print("Ingresa los valores ");
    fila=1;
    LCD_I2C_setCursor(columna,fila);
    LCD_I2C_print("en MiliNewton(mN)");
    CyDelay(600);
    LCD_I2C_clear();
    /***********************************/
    for(;;)
    {
        /*****************Recogiendo el valor del arduino*******/
        while(UART_GetRxBufferSize()>=1)
        {
            recibir=UART_GetChar();
            if (str_index < STRBUF_LEN) 
            {
                str4[str_index++] = recibir;
            }   
        }
        str_index = 0 ;
        //UART_PutString(str4);
        /***************************Imprimir el Valor de la Galga********************************/
        columna=0;
        fila=2;
        LCD_I2C_setCursor(columna,fila);
        LCD_I2C_print("mN=");
        LCD_I2C_print(str4);
        LCD_I2C_print("   ");
        /***************************Recoger los valores del ADC*********************************/
        /***************************Canal 1*****************************************************/
        AMux_1_FastSelect(0);
        columna=0;
        fila=3;
        LCD_I2C_setCursor(columna,fila);
        LCD_I2C_print("mV=");
        
        ADC_StartConvert();
        ADC_IsEndConversion(ADC_WAIT_FOR_RESULT);
        entero[0]=ADC_GetResult32();
        ADC_StopConvert();
        voltaje[0]=ADC_CountsTo_mVolts(entero[0]);
        aux[0]=voltaje[0];
        
        sprintf(str,"%.0f",aux[0]);
        LCD_I2C_print(str);
        LCD_I2C_print("   ");
        /***************************Canal 2*****************************************************/
        AMux_1_FastSelect(1);
        columna=10;
        fila=3;
        LCD_I2C_setCursor(columna,fila);
        LCD_I2C_print("mV=");
        
        ADC_StartConvert();
        ADC_IsEndConversion(ADC_WAIT_FOR_RESULT);
        entero[1]=ADC_GetResult32();
        ADC_StopConvert();
        voltaje[1]=ADC_CountsTo_mVolts(entero[1]);
        aux[1]=voltaje[1];
        
        sprintf(str2,"%.0f",aux[1]);
        LCD_I2C_print(str2);
        LCD_I2C_print(" ");
        /***************************************************************************************/
        /*************************************Teclado*******************************************/
        /***************************************************************************************/
        if((i!='A')&&(i!='C'))//SI no se presiona A ni C
        {
            columna=0;
            fila=0;
            LCD_I2C_setCursor(columna,fila);
            LCD_I2C_print("Ingrese Valor");
            columna=0;
            fila=1;
            LCD_I2C_setCursor(columna,fila);
            LCD_I2C_print("mN=");
            if(cuenta<5)   
            LCD_I2C_print(numero);
        }
        if(i=='A')//Si se presiona A
        {
            DIR_Write(0);
            STEP_Write(1);
            CyDelay(10);
            STEP_Write(0);
            CyDelay(100);
        }
        if(i=='B')
        {
            DIR_Write(1);
            STEP_Write(1);
            CyDelay(10);
            STEP_Write(0);
            CyDelay(100);
        }
        if(i=='C')//Si se presiona B
        {
            i='\0';
            LCD_I2C_clear();   
        }
        if(i=='D')//Si se presiona C
        {
            if(tx==0) 
            {
                tx=1;
                LCD_I2C_setCursor(0,0);
                LCD_I2C_print(" Transmitiendo  ");
                i='\0';
                /**********************/
                PWM_Start();/*PWM*/
                CyDelay(1000);
                /***********************/
                i='\0';
                LCD_I2C_clear();
            }
            else
            {
                PWM_Stop();
                tx=0;
                i='\0';
                LCD_I2C_clear();
            }
        }    
    }
}

/* [] END OF FILE */
