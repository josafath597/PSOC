/*******************************************************************************
* File Name: InAnalog.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_InAnalog_H) /* Pins InAnalog_H */
#define CY_PINS_InAnalog_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "InAnalog_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 InAnalog__PORT == 15 && ((InAnalog__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    InAnalog_Write(uint8 value);
void    InAnalog_SetDriveMode(uint8 mode);
uint8   InAnalog_ReadDataReg(void);
uint8   InAnalog_Read(void);
void    InAnalog_SetInterruptMode(uint16 position, uint16 mode);
uint8   InAnalog_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the InAnalog_SetDriveMode() function.
     *  @{
     */
        #define InAnalog_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define InAnalog_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define InAnalog_DM_RES_UP          PIN_DM_RES_UP
        #define InAnalog_DM_RES_DWN         PIN_DM_RES_DWN
        #define InAnalog_DM_OD_LO           PIN_DM_OD_LO
        #define InAnalog_DM_OD_HI           PIN_DM_OD_HI
        #define InAnalog_DM_STRONG          PIN_DM_STRONG
        #define InAnalog_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define InAnalog_MASK               InAnalog__MASK
#define InAnalog_SHIFT              InAnalog__SHIFT
#define InAnalog_WIDTH              1u

/* Interrupt constants */
#if defined(InAnalog__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in InAnalog_SetInterruptMode() function.
     *  @{
     */
        #define InAnalog_INTR_NONE      (uint16)(0x0000u)
        #define InAnalog_INTR_RISING    (uint16)(0x0001u)
        #define InAnalog_INTR_FALLING   (uint16)(0x0002u)
        #define InAnalog_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define InAnalog_INTR_MASK      (0x01u) 
#endif /* (InAnalog__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define InAnalog_PS                     (* (reg8 *) InAnalog__PS)
/* Data Register */
#define InAnalog_DR                     (* (reg8 *) InAnalog__DR)
/* Port Number */
#define InAnalog_PRT_NUM                (* (reg8 *) InAnalog__PRT) 
/* Connect to Analog Globals */                                                  
#define InAnalog_AG                     (* (reg8 *) InAnalog__AG)                       
/* Analog MUX bux enable */
#define InAnalog_AMUX                   (* (reg8 *) InAnalog__AMUX) 
/* Bidirectional Enable */                                                        
#define InAnalog_BIE                    (* (reg8 *) InAnalog__BIE)
/* Bit-mask for Aliased Register Access */
#define InAnalog_BIT_MASK               (* (reg8 *) InAnalog__BIT_MASK)
/* Bypass Enable */
#define InAnalog_BYP                    (* (reg8 *) InAnalog__BYP)
/* Port wide control signals */                                                   
#define InAnalog_CTL                    (* (reg8 *) InAnalog__CTL)
/* Drive Modes */
#define InAnalog_DM0                    (* (reg8 *) InAnalog__DM0) 
#define InAnalog_DM1                    (* (reg8 *) InAnalog__DM1)
#define InAnalog_DM2                    (* (reg8 *) InAnalog__DM2) 
/* Input Buffer Disable Override */
#define InAnalog_INP_DIS                (* (reg8 *) InAnalog__INP_DIS)
/* LCD Common or Segment Drive */
#define InAnalog_LCD_COM_SEG            (* (reg8 *) InAnalog__LCD_COM_SEG)
/* Enable Segment LCD */
#define InAnalog_LCD_EN                 (* (reg8 *) InAnalog__LCD_EN)
/* Slew Rate Control */
#define InAnalog_SLW                    (* (reg8 *) InAnalog__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define InAnalog_PRTDSI__CAPS_SEL       (* (reg8 *) InAnalog__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define InAnalog_PRTDSI__DBL_SYNC_IN    (* (reg8 *) InAnalog__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define InAnalog_PRTDSI__OE_SEL0        (* (reg8 *) InAnalog__PRTDSI__OE_SEL0) 
#define InAnalog_PRTDSI__OE_SEL1        (* (reg8 *) InAnalog__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define InAnalog_PRTDSI__OUT_SEL0       (* (reg8 *) InAnalog__PRTDSI__OUT_SEL0) 
#define InAnalog_PRTDSI__OUT_SEL1       (* (reg8 *) InAnalog__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define InAnalog_PRTDSI__SYNC_OUT       (* (reg8 *) InAnalog__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(InAnalog__SIO_CFG)
    #define InAnalog_SIO_HYST_EN        (* (reg8 *) InAnalog__SIO_HYST_EN)
    #define InAnalog_SIO_REG_HIFREQ     (* (reg8 *) InAnalog__SIO_REG_HIFREQ)
    #define InAnalog_SIO_CFG            (* (reg8 *) InAnalog__SIO_CFG)
    #define InAnalog_SIO_DIFF           (* (reg8 *) InAnalog__SIO_DIFF)
#endif /* (InAnalog__SIO_CFG) */

/* Interrupt Registers */
#if defined(InAnalog__INTSTAT)
    #define InAnalog_INTSTAT            (* (reg8 *) InAnalog__INTSTAT)
    #define InAnalog_SNAP               (* (reg8 *) InAnalog__SNAP)
    
	#define InAnalog_0_INTTYPE_REG 		(* (reg8 *) InAnalog__0__INTTYPE)
#endif /* (InAnalog__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_InAnalog_H */


/* [] END OF FILE */
