/*******************************************************************************
* File Name: pulisr.c  
* Version 1.70
*
*  Description:
*   API for controlling the state of an interrupt.
*
*
*  Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/


#include <cydevice_trm.h>
#include <CyLib.h>
#include <pulisr.h>
#include "cyapicallbacks.h"

#if !defined(pulisr__REMOVED) /* Check for removal by optimization */

/*******************************************************************************
*  Place your includes, defines and code here 
********************************************************************************/
/* `#START pulisr_intc` */

/* `#END` */

#ifndef CYINT_IRQ_BASE
#define CYINT_IRQ_BASE      16
#endif /* CYINT_IRQ_BASE */
#ifndef CYINT_VECT_TABLE
#define CYINT_VECT_TABLE    ((cyisraddress **) CYREG_NVIC_VECT_OFFSET)
#endif /* CYINT_VECT_TABLE */

/* Declared in startup, used to set unused interrupts to. */
CY_ISR_PROTO(IntDefaultHandler);


/*******************************************************************************
* Function Name: pulisr_Start
********************************************************************************
*
* Summary:
*  Set up the interrupt and enable it. This function disables the interrupt, 
*  sets the default interrupt vector, sets the priority from the value in the
*  Design Wide Resources Interrupt Editor, then enables the interrupt to the 
*  interrupt controller.
*
* Parameters:  
*   None
*
* Return:
*   None
*
*******************************************************************************/
void pulisr_Start(void)
{
    /* For all we know the interrupt is active. */
    pulisr_Disable();

    /* Set the ISR to point to the pulisr Interrupt. */
    pulisr_SetVector(&pulisr_Interrupt);

    /* Set the priority. */
    pulisr_SetPriority((uint8)pulisr_INTC_PRIOR_NUMBER);

    /* Enable it. */
    pulisr_Enable();
}


/*******************************************************************************
* Function Name: pulisr_StartEx
********************************************************************************
*
* Summary:
*  Sets up the interrupt and enables it. This function disables the interrupt,
*  sets the interrupt vector based on the address passed in, sets the priority 
*  from the value in the Design Wide Resources Interrupt Editor, then enables 
*  the interrupt to the interrupt controller.
*  
*  When defining ISR functions, the CY_ISR and CY_ISR_PROTO macros should be 
*  used to provide consistent definition across compilers:
*  
*  Function definition example:
*   CY_ISR(MyISR)
*   {
*   }
*   Function prototype example:
*   CY_ISR_PROTO(MyISR);
*
* Parameters:  
*   address: Address of the ISR to set in the interrupt vector table.
*
* Return:
*   None
*
*******************************************************************************/
void pulisr_StartEx(cyisraddress address)
{
    /* For all we know the interrupt is active. */
    pulisr_Disable();

    /* Set the ISR to point to the pulisr Interrupt. */
    pulisr_SetVector(address);

    /* Set the priority. */
    pulisr_SetPriority((uint8)pulisr_INTC_PRIOR_NUMBER);

    /* Enable it. */
    pulisr_Enable();
}


/*******************************************************************************
* Function Name: pulisr_Stop
********************************************************************************
*
* Summary:
*   Disables and removes the interrupt.
*
* Parameters:  
*   None
*
* Return:
*   None
*
*******************************************************************************/
void pulisr_Stop(void)
{
    /* Disable this interrupt. */
    pulisr_Disable();

    /* Set the ISR to point to the passive one. */
    pulisr_SetVector(&IntDefaultHandler);
}


/*******************************************************************************
* Function Name: pulisr_Interrupt
********************************************************************************
*
* Summary:
*   The default Interrupt Service Routine for pulisr.
*
*   Add custom code between the coments to keep the next version of this file
*   from over writting your code.
*
* Parameters:  
*
* Return:
*   None
*
*******************************************************************************/
CY_ISR(pulisr_Interrupt)
{
    #ifdef pulisr_INTERRUPT_INTERRUPT_CALLBACK
        pulisr_Interrupt_InterruptCallback();
    #endif /* pulisr_INTERRUPT_INTERRUPT_CALLBACK */ 

    /*  Place your Interrupt code here. */
    /* `#START pulisr_Interrupt` */

    /* `#END` */
}


/*******************************************************************************
* Function Name: pulisr_SetVector
********************************************************************************
*
* Summary:
*   Change the ISR vector for the Interrupt. Note calling pulisr_Start
*   will override any effect this method would have had. To set the vector 
*   before the component has been started use pulisr_StartEx instead.
* 
*   When defining ISR functions, the CY_ISR and CY_ISR_PROTO macros should be 
*   used to provide consistent definition across compilers:
*
*   Function definition example:
*   CY_ISR(MyISR)
*   {
*   }
*
*   Function prototype example:
*     CY_ISR_PROTO(MyISR);
*
* Parameters:
*   address: Address of the ISR to set in the interrupt vector table.
*
* Return:
*   None
*
*******************************************************************************/
void pulisr_SetVector(cyisraddress address)
{
    cyisraddress * ramVectorTable;

    ramVectorTable = (cyisraddress *) *CYINT_VECT_TABLE;

    ramVectorTable[CYINT_IRQ_BASE + (uint32)pulisr__INTC_NUMBER] = address;
}


/*******************************************************************************
* Function Name: pulisr_GetVector
********************************************************************************
*
* Summary:
*   Gets the "address" of the current ISR vector for the Interrupt.
*
* Parameters:
*   None
*
* Return:
*   Address of the ISR in the interrupt vector table.
*
*******************************************************************************/
cyisraddress pulisr_GetVector(void)
{
    cyisraddress * ramVectorTable;

    ramVectorTable = (cyisraddress *) *CYINT_VECT_TABLE;

    return ramVectorTable[CYINT_IRQ_BASE + (uint32)pulisr__INTC_NUMBER];
}


/*******************************************************************************
* Function Name: pulisr_SetPriority
********************************************************************************
*
* Summary:
*   Sets the Priority of the Interrupt. 
*
*   Note calling pulisr_Start or pulisr_StartEx will 
*   override any effect this API would have had. This API should only be called
*   after pulisr_Start or pulisr_StartEx has been called. 
*   To set the initial priority for the component, use the Design-Wide Resources
*   Interrupt Editor.
*
*   Note This API has no effect on Non-maskable interrupt NMI).
*
* Parameters:
*   priority: Priority of the interrupt, 0 being the highest priority
*             PSoC 3 and PSoC 5LP: Priority is from 0 to 7.
*             PSoC 4: Priority is from 0 to 3.
*
* Return:
*   None
*
*******************************************************************************/
void pulisr_SetPriority(uint8 priority)
{
    *pulisr_INTC_PRIOR = priority << 5;
}


/*******************************************************************************
* Function Name: pulisr_GetPriority
********************************************************************************
*
* Summary:
*   Gets the Priority of the Interrupt.
*
* Parameters:
*   None
*
* Return:
*   Priority of the interrupt, 0 being the highest priority
*    PSoC 3 and PSoC 5LP: Priority is from 0 to 7.
*    PSoC 4: Priority is from 0 to 3.
*
*******************************************************************************/
uint8 pulisr_GetPriority(void)
{
    uint8 priority;


    priority = *pulisr_INTC_PRIOR >> 5;

    return priority;
}


/*******************************************************************************
* Function Name: pulisr_Enable
********************************************************************************
*
* Summary:
*   Enables the interrupt to the interrupt controller. Do not call this function
*   unless ISR_Start() has been called or the functionality of the ISR_Start() 
*   function, which sets the vector and the priority, has been called.
*
* Parameters:
*   None
*
* Return:
*   None
*
*******************************************************************************/
void pulisr_Enable(void)
{
    /* Enable the general interrupt. */
    *pulisr_INTC_SET_EN = pulisr__INTC_MASK;
}


/*******************************************************************************
* Function Name: pulisr_GetState
********************************************************************************
*
* Summary:
*   Gets the state (enabled, disabled) of the Interrupt.
*
* Parameters:
*   None
*
* Return:
*   1 if enabled, 0 if disabled.
*
*******************************************************************************/
uint8 pulisr_GetState(void)
{
    /* Get the state of the general interrupt. */
    return ((*pulisr_INTC_SET_EN & (uint32)pulisr__INTC_MASK) != 0u) ? 1u:0u;
}


/*******************************************************************************
* Function Name: pulisr_Disable
********************************************************************************
*
* Summary:
*   Disables the Interrupt in the interrupt controller.
*
* Parameters:
*   None
*
* Return:
*   None
*
*******************************************************************************/
void pulisr_Disable(void)
{
    /* Disable the general interrupt. */
    *pulisr_INTC_CLR_EN = pulisr__INTC_MASK;
}


/*******************************************************************************
* Function Name: pulisr_SetPending
********************************************************************************
*
* Summary:
*   Causes the Interrupt to enter the pending state, a software method of
*   generating the interrupt.
*
* Parameters:
*   None
*
* Return:
*   None
*
* Side Effects:
*   If interrupts are enabled and the interrupt is set up properly, the ISR is
*   entered (depending on the priority of this interrupt and other pending 
*   interrupts).
*
*******************************************************************************/
void pulisr_SetPending(void)
{
    *pulisr_INTC_SET_PD = pulisr__INTC_MASK;
}


/*******************************************************************************
* Function Name: pulisr_ClearPending
********************************************************************************
*
* Summary:
*   Clears a pending interrupt in the interrupt controller.
*
*   Note Some interrupt sources are clear-on-read and require the block 
*   interrupt/status register to be read/cleared with the appropriate block API 
*   (GPIO, UART, and so on). Otherwise the ISR will continue to remain in 
*   pending state even though the interrupt itself is cleared using this API.
*
* Parameters:
*   None
*
* Return:
*   None
*
*******************************************************************************/
void pulisr_ClearPending(void)
{
    *pulisr_INTC_CLR_PD = pulisr__INTC_MASK;
}

#endif /* End check for removal by optimization */


/* [] END OF FILE */
